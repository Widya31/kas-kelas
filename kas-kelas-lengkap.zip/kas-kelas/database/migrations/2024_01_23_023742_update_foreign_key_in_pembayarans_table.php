<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        // Generate a unique constraint name
        $constraintName = 'fk_pembayarans_id_siswa';

        Schema::table('pembayarans', function (Blueprint $table) use ($constraintName) {
            $table->dropForeign(['id_siswa']);

            $table->foreign('id_siswa', $constraintName)->references('id')->on('siswas')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    
    {
        Schema::table('pembayarans', function (Blueprint $table) {
            //
        });
    }
};
