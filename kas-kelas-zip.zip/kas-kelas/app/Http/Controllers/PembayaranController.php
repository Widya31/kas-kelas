<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Siswa;
use App\Models\Pembayaran;

class PembayaranController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //get posts
        $pembayarans = Pembayaran::latest()->paginate(5);

        //render view with posts
        return view('pembayarans.index', compact('pembayarans'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $siswas = Siswa::all(); // Assuming you have a Siswa model

        return view('pembayarans.create', compact('siswas'));
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    // public function store(Request $request)
    // {
    //     // Validate form
    //     $this->validate($request, [
    //         'id_siswa'     => 'required|min:1', // Ganti min:5 menjadi min:1 karena id biasanya tidak terlalu panjang
    //         'tgl_bayar'    => 'required|date', // Ganti min:5 menjadi date untuk memastikan format tanggal
    //         'jumlah_bayar' => 'required|numeric', // Ganti min:5 menjadi numeric untuk memastikan nilai numerik
    //     ]);

    //     // Create post
    //     Pembayaran::create([
    //         'id_siswa'     => $request->id_siswa,
    //         'tgl_bayar'    => $request->tgl_bayar,
    //         'jumlah_bayar' => $request->jumlah_bayar,
    //     ]);

    //     // Redirect to index with success message
    //     return redirect()->route('pembayarans.index')->with(['success' => 'Data Berhasil Disimpan!']);
    // }

    public function store(Request $request)
    {
        // Validate form
        $this->validate($request, [
            'id_siswa'     => 'required|min:1',
            'tgl_bayar'    => 'required|date',
            'jumlah_bayar' => 'required|numeric',
        ]);

        // Check if a record with the same id_siswa already exists
        $existingRecord = Pembayaran::where('id_siswa', $request->id_siswa)->first();

        if ($existingRecord) {
            // If the record exists, update it
            $existingRecord->update([
                'tgl_bayar'    => $request->tgl_bayar,
                'jumlah_bayar' => $existingRecord->jumlah_bayar + $request->jumlah_bayar,
            ]);

            // Redirect to index with success message
            return redirect()->route('pembayarans.index')->with(['success' => 'Data Berhasil Diupdate!']);
        } else {
            // If the record does not exist, create a new one
            Pembayaran::create([
                'id_siswa'     => $request->id_siswa,
                'tgl_bayar'    => $request->tgl_bayar,
                'jumlah_bayar' => $request->jumlah_bayar,
            ]);

            // Redirect to index with success message
            return redirect()->route('pembayarans.index')->with(['success' => 'Data Berhasil Disimpan!']);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Pembayaran $pembayaran)
    {
        $siswas = Siswa::all();

        return view('pembayarans.edit', compact('pembayaran', 'siswas'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Pembayaran $pembayaran)
    {
        // Validate form
        $this->validate($request, [
            'id_siswa'     => 'required|exists:siswas,id',
            'tgl_bayar'    => 'required|date',
            'jumlah_bayar' => 'required|numeric',
        ]);
    
        // Check if related Siswa exists
        $siswa = Siswa::find($request->id_siswa);
        if (!$siswa) {
            // Handle the case where Siswa does not exist
            return redirect()->route('pembayarans.index')->with(['error' => 'Siswa not found!']);
        }
    
        // $nominallama = $pembayaran->jumlah_bayar;

        // $nominalbaru = $nominallama + $request->jumlah_bayar;
    
        // // Update Pembayaran
        // $pembayaran->update([
        //     'id_siswa'     => $request->id_siswa,
        //     'tgl_bayar'    => $request->tgl_bayar,
        //     'jumlah_bayar' =>  $nominalbaru
        // ]);

        // Update Pembayaran
        $pembayaran->update([
            'id_siswa'     => $request->id_siswa,
            'tgl_bayar'    => $request->tgl_bayar,
            'jumlah_bayar' => $request->jumlah_bayar,
        ]);
    
        // Redirect to index with success message
        return redirect()->route('pembayarans.index')->with(['success' => 'Data Berhasil Diubah!']);
    }
    
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Pembayaran $pembayaran)
    {
        //delete post
        $pembayaran->delete();
 
        //redirect to index
        return redirect()->route('pembayarans.index')->with(['success' => 'Data Berhasil Dihapus!']);
    }
}
